<?php
    
    require 'init.php';
    // $catType = 1;
    // $srchType = "carpentry";
    // $locType = 1;

    $catType = $_POST["catType"];
    $srchType = $_POST["srchType"];
    $locType = $_POST["locType"];
	$pageNo = $_POST["pageNo"];
	$offset_count = 25;
    $i=0;
	$totalPageNo = 0;
	$pageNo = ($pageNo -1)* $offset_count;
    if($catType != null){
        if($srchType != ""){
        	$sqlSub = "SELECT COUNT(*) FROM `profile_table` WHERE `category`= (SELECT `name` FROM `category` WHERE `id`=$catType) AND `location` = (SELECT `name` FROM `location` WHERE `id`=$locType) AND (`name` LIKE '%$srchType%' OR `role` LIKE '%$srchType%' OR `skils` LIKE '%$srchType%');";
            $sql = "SELECT * FROM `profile_table` WHERE `category`= (SELECT `name` FROM `category` WHERE `id`=$catType) AND `location` = (SELECT `name` FROM `location` WHERE `id`=$locType) AND (`name` LIKE '%$srchType%' OR `role` LIKE '%$srchType%' OR `skils` LIKE '%$srchType%') LIMIT $offset_count OFFSET $pageNo;";
        } else {
        	$sqlSub = "SELECT COUNT(*) FROM `profile_table` WHERE `category`= (SELECT `name` FROM `category` WHERE `id`=$catType)";
            $sql = "SELECT * FROM `profile_table` WHERE `category`= (SELECT `name` FROM `category` WHERE `id`=$catType) LIMIT 10 OFFSET $pageNo ";
        }
    } else if($srchType != ""){
    	$sqlSub = "SELECT COUNT(*) FROM `profile_table` WHERE `location` = (SELECT `name` FROM `location` WHERE `id`=$locType) AND (`category` LIKE '%$srchType%' OR `name` LIKE '%$srchType%' OR `role` LIKE '%$srchType%' OR `skils` LIKE '%$srchType%');";
        $sql = "SELECT * FROM `profile_table` WHERE `location` = (SELECT `name` FROM `location` WHERE `id`=$locType) AND (`category` LIKE '%$srchType%' OR `name` LIKE '%$srchType%' OR `role` LIKE '%$srchType%' OR `skils` LIKE '%$srchType%') LIMIT $offset_count OFFSET $pageNo ;";
    }
	else if($srchType == ""){
    	$sqlSub ="SELECT COUNT(*) FROM `profile_table` WHERE `location` = (SELECT `name` FROM `location` WHERE `id`=$locType) AND (`category` LIKE '%$srchType%' OR `name` LIKE '%$srchType%' OR `role` LIKE '%$srchType%' OR `skils` LIKE '%$srchType%');";
        $sql = "SELECT * FROM `profile_table` WHERE `location` = (SELECT `name` FROM `location` WHERE `id`=$locType) AND (`category` LIKE '%$srchType%' OR `name` LIKE '%$srchType%' OR `role` LIKE '%$srchType%' OR `skils` LIKE '%$srchType%') LIMIT $offset_count OFFSET $pageNo;";
    	// echo $sql;
    }
    // echo $sql;
    $resultSub = mysqli_query($con,$sqlSub);
    $row = mysqli_fetch_array($resultSub);
    $totalPageNo = $row[0];
    $result = mysqli_query($con,$sql);
    $userData[$i++] = array("count"=>mysqli_num_rows($result),"totalpageNo"=>$totalPageNo,"pageLimit"=>$offset_count);
    while($row = mysqli_fetch_array($result)){
        
        $userData[$i] = array("userName"=>$row["name"],"userRole"=>$row["role"],"userLoc"=>$row["location"],"userSubLoc"=>$row["sublocation"],"userWPhone"=>$row["whatapp"],"userMail"=>$row["email"],"userPhone"=>$row["phone"],"userId"=>$row["id"],"rating"=>$row["rating"],"review"=>$row["review"],"toRating"=>$row["totRating"],"card"=>$row["card"],"premium"=>$row["premium"]);
        $i+=1;

    }
    if($i != 0){
	    $jsonData = json_encode($userData);
        echo $jsonData;
    } else {
        echo '0';
    }
?>