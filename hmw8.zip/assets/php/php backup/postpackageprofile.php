<?php
        $u_id = $_POST["id"];
        $em_id = $_POST["emid"];
        $month = $_POST["month"];
		$callAction = $_POST["callAction"];
        require "init.php";//needed for connection with database

        if($em_id != 0){
            $sql_query = "SELECT uniqueId FROM `profile_table` WHERE id = $u_id ";
            $result = mysqli_query($con,$sql_query);
            $row = mysqli_fetch_assoc($result);
        	if($callAction == "company"){
            	$imagelink = "assets/img/profile/card/".$row["uniqueId"]."Gold.png";
            }
        	else if($callAction == "personel"){
            	$imagelink = "assets/img/profile/card/".$row["uniqueId"]."Blue.png";
            }
        	if($month == 0){
            	$sql_query = "UPDATE `profile_table` SET `premium`=1,`employee_id`= $em_id ,`card`= '$imagelink',`isActive`=1 WHERE  id = $u_id ;";
            }
        	else{
            	$sql_query = "UPDATE `profile_table` SET `premium`=1,`employee_id`= $em_id ,`card`= '$imagelink',`isActive`=1,`doe` = DATE_ADD(CURRENT_DATE, INTERVAL $month MONTH) WHERE  id = $u_id ;";
            }
            $result = mysqli_query($con,$sql_query);
            echo $u_id;
        }
        else if($em_id == 0 || $em_id == ""){
            $sql_query = "SELECT uniqueId FROM `profile_table` WHERE id = $u_id ";
            $result = mysqli_query($con,$sql_query);
            $row = mysqli_fetch_assoc($result);
            if($callAction == "company"){
            	$imagelink = "assets/img/profile/card/".$row["uniqueId"]."Gold.png";
            }
        	else if($callAction == "personel"){
            	$imagelink = "assets/img/profile/card/".$row["uniqueId"]."Blue.png";
            }
        	if($month == 0){
            	$sql_query = "UPDATE `profile_table` SET `premium`=1,`isActive`=1,`card`= '$imagelink' WHERE id = $u_id ;";
            }
        	else{
            	$sql_query = "UPDATE `profile_table` SET `premium`=1,`isActive`=1,`card`= '$imagelink',`doe` = DATE_ADD(CURRENT_DATE, INTERVAL $month MONTH) WHERE id = $u_id ;";	
            }
            $result = mysqli_query($con,$sql_query);
            echo $u_id;   
        }
?> 